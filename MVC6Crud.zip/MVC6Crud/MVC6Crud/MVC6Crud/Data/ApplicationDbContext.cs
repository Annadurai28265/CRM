﻿using Microsoft.EntityFrameworkCore;
using CRMWebApp.Models;

namespace CRMWebApp.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Customer> customers { get; set; }       
    }
}
