﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using CRMWebApp.Data;
using CRMWebApp.Models;
using CRMWebApp.ViewModel;

namespace CRMWebApp.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ApplicationDbContext _context;
        public CustomerController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            List<CustomerListViewModel> customerListViewModelList = new List<CustomerListViewModel>();
            var customerList = _context.customers;
            if (customerList != null)
            {
                foreach (var item in customerList)
                {
                    CustomerListViewModel customerListViewModel = new CustomerListViewModel();
                    customerListViewModel.Id = item.Id;
                    customerListViewModel.Name = item.Name;
                    customerListViewModel.Description = item.Description;
                    customerListViewModel.Email = item.Email;
                    customerListViewModel.Phone = item.Phone;
                    customerListViewModel.CategoryId = item.CategoryId;
                    
                    customerListViewModel.CategoryName = _context.Categories.Where(c => c.CategoryId == item.CategoryId).Select(c => c.CategoryName).FirstOrDefault();
                    customerListViewModelList.Add(customerListViewModel);
                }
            }
            return View(customerListViewModelList);           
        }

        public IActionResult Create()
        {
            CustomerViewModel customerCreateViewModel = new CustomerViewModel();
            customerCreateViewModel.Category = (IEnumerable<SelectListItem>)_context.Categories.Select(c => new SelectListItem()
            {
                Text = c.CategoryName,
                Value = c.CategoryId.ToString()
            });

            return View(customerCreateViewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CustomerViewModel customerCreateViewModel)
        {
            customerCreateViewModel.Category = (IEnumerable<SelectListItem>)_context.Categories.Select(c => new SelectListItem()
            {
                Text = c.CategoryName,
                Value = c.CategoryId.ToString()
            });
            var customer = new Customer()
            {
                Name = customerCreateViewModel.Name,
                Description = customerCreateViewModel.Description,
                Email = customerCreateViewModel.Email,
                Phone = customerCreateViewModel.Phone,
                CategoryId = customerCreateViewModel.CategoryId,
        
            };
            ModelState.Remove("Category");
            if (ModelState.IsValid)
            {
                _context.customers.Add(customer);
                _context.SaveChanges();
                TempData["SuccessMsg"] = "customer ("+ customer.Name + ") added successfully.";
                return RedirectToAction("Index");
            }
            
            return View(customerCreateViewModel);
        }

        public IActionResult Edit(int? id)
        {
            var customerToEdit = _context.customers.Find(id);
            if (customerToEdit != null)
            {
                var customerViewModel = new CustomerViewModel()
                {
                    Id = customerToEdit.Id,
                    Name = customerToEdit.Name,
                    Description = customerToEdit.Description,
                    Email = customerToEdit.Email,
                    CategoryId = customerToEdit.CategoryId,
                    Phone = customerToEdit.Phone,

                    Category = (IEnumerable<SelectListItem>)_context.Categories.Select(c => new SelectListItem()
                    {
                        Text = c.CategoryName,
                        Value = c.CategoryId.ToString()                        
                    })
                };
                return View(customerViewModel);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(CustomerViewModel customerViewModel)
        {
            customerViewModel.Category = (IEnumerable<SelectListItem>)_context.Categories.Select(c => new SelectListItem()
            {
                Text = c.CategoryName,
                Value = c.CategoryId.ToString()
            });
            var customer = new Customer()
            {
                Id = customerViewModel.Id,
                Name = customerViewModel.Name,
                Description = customerViewModel.Description,
                Email = customerViewModel.Email,
                Phone = customerViewModel.Phone,
                CategoryId = customerViewModel.CategoryId,

            };
            ModelState.Remove("Category");
            if (ModelState.IsValid)
            {
                _context.customers.Update(customer);
                _context.SaveChanges();
                TempData["SuccessMsg"] = "customer (" + customer.Name + ") updated successfully !";
                return RedirectToAction("Index");
            }

            return View(customerViewModel);
        }
        public IActionResult Delete(int? id)
        {
            var customerToEdit = _context.customers.Find(id);
            if (customerToEdit != null)
            {
                var customerViewModel = new CustomerViewModel()
                {
                    Id = customerToEdit.Id,
                    Name = customerToEdit.Name,
                    Description = customerToEdit.Description,
                    Email = customerToEdit.Email,
                    CategoryId = customerToEdit.CategoryId,
                    Phone = customerToEdit.Phone,
                    Category = (IEnumerable<SelectListItem>)_context.Categories.Select(c => new SelectListItem()
                    {
                        Text = c.CategoryName,
                        Value = c.CategoryId.ToString()
                    })
                };
                return View(customerViewModel);
            }
            else {
                return RedirectToAction("Index");
            }            
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteCustomer(int? id)
        {
            var customer = _context.customers.Find(id);
            if (customer == null)
            {
                return NotFound();
            }
            _context.customers.Remove(customer);
            _context.SaveChanges();
            TempData["SuccessMsg"] = "customer (" + customer.Name + ") deleted successfully.";
            return RedirectToAction("Index");
        }
    }
}
