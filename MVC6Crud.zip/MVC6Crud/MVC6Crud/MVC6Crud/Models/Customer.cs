﻿using System.ComponentModel.DataAnnotations;

namespace CRMWebApp.Models
{
    public class Customer
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [Display(Name ="Customer Name")]
        public string? Name { get; set; }
        public string? Description { get; set; }
        [Required]
        public string? Email { get; set; }
        [Required]
        public string? Phone { get; set; }
        [Required]
        public int CategoryId { get; set; }       
    }
}
